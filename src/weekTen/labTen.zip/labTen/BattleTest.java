package weekTen.labTen;

public class BattleTest {
    public static void main(String[] args) {
// Creates two characters for the battle
        Allstar allstar = new Allstar("Thor", 100, 30);
        Sunflower sunflower = new Sunflower("Gandalf", 80, 50);
        System.out.println("Battle Start!");
// Game loops: Continue the battle until one character's health reaches 0
        while (((Character) allstar).isAlive() && ((Character) sunflower).isAlive()) {
// Warrior attacks Mage
            allstar.attack();
            ((Character) sunflower).setHealth(((Character) sunflower).getHealth() - 10);
            if (!((Character) sunflower).isAlive()) {
                System.out.println("\nMage: "+((Character)sunflower).getName() + " has been defeated!");
                break;
            }
// Mage attacks Warrior
            sunflower.attack();
            ((Character) allstar).setHealth(((Character) allstar).getHealth() -
                    15);
            if (!((Character) allstar).isAlive()) {
                System.out.println("\nWarrior: "+((Character)allstar).getName() + " has been defeated!");
                break;
            }
        }
// Prints the winner
        if (((Character) allstar).isAlive()) {
            System.out.println("\nWarrior: "+((Character)allstar).getName() + " wins the battle!");
        } else {
            System.out.println("\nMage: "+((Character)allstar).getName() + " wins the battle!");
        }
    }
}

