package weekTen.interfaces;

import weekTen.interfaces.abstractClasses.ApartmentBook;

public interface Listable {
    void listProperties();
}
